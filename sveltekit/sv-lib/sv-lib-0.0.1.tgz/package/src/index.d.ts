declare module 'sv-lib'
